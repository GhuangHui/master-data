#"Wed Feb 03 10:42:01 2021"
date()
library(Matrix)
library(lme4)
library(nlme)
library(lmerTest)
library(readxl)
library(tidyverse)
library(dplyr)
setwd("F:/�о�������/R���Դ���/ģ��/ʦ�ַ���/��Ӧ��")
data<-read.csv("lake.csv")

head(data)
length(data$study)
#  rows

#rename some long names in the dataset for easy coding :)
data$N=data$TN_mg_L
data$P=data$TP_mg_L
data$Chl=data$Chl.a_ug_L

length(data$N)
data$N=as.numeric(data$N)
max(data$N)

length(data$P)
data$P=as.numeric(data$P)
max(data$P)

# compute lnR for Chl 
uniq= unique(data$study)
uniq
length(uniq)
data1=c() 
data2=c()

# it is important to learn for loop in R
# try to understand one level for loop first, and second level and so on


for (i in 1:length(uniq)) 
{subdata=subset(data, study==uniq[i]) # for each study, make a subdata
#uniq_y=unique(subdata$Year)
#for (y in 1:length(uniq_y)) # for each year with a study, make a (sub)subdata
#{ subdata=subset(subdata, Year==uniq_y[y])
#uniq_C=unique(subdata$Crop)
#for (C in 1:length(uniq_C)) #for the crops of each study
#{subdata=subset(subdata,Crop==uniq_C)
#uniq_cou=unique(subdata$Cou)
#for (cou in 1:length(uniq_cou)) #for the countries of the each study, make a (sub) subdata
#{subdata_cou=subset(subdata, Cou==uniq_cou[cou])}
#uniq_cu=unique(subdata_cou$cu)
#for (cu in 1:length(uniq_cu)) # for the cultivar for each study, make a (sub)subdata
#{ subdata_cu=subset(subdata_cou, cu==uniq_cu[cu])}
med_N1=mean(subdata$TN_r1)
med_N2=mean(subdata$TN_r2)

subdata$N_level[subdata$N<med_N1]="-N"
subdata$N_level[subdata$N<=med_N2&subdata$N>=med_N1]="N"
subdata$N_level[subdata$N>med_N2]="+N"
ref=min(subdata$Chl)
lnR=log(subdata$Chl/ref) # this is to calculate lnR for Chl
data1=cbind(subdata,lnR)
data2=rbind(data2,data1)}

data=data2
head(data)
tail(data)

unique(data$N_level)
#unique(data$P_level)
table(data$N_level)


min(data$lnR)
max(data$lnR)

# lnR ~ N level
model_d=lme(lnR~N_level,random=~1|study,data)# mixed-effect model
summary(model_d)

#extract coefficients from the summary
summary(model_d)$tTable # try to understand the results
coef<-data.frame(summary(model_d)$tTable[c(1,2,3),c(1,2,5)]);coef 
# c(1,2) are row numbers, c(1,2,5) are column numbers
t_crit<-qt(0.025,summary(model_d)$tTable[c(1,2,3),3]);t_crit 
# to determine the value from t distribution 
confd<-coef[,2]*abs(t_crit)
confdMin <- coef[,1] - confd # lower limit
confdMax <- coef[,1] + confd # upper limit
comparID=c(1:3)
comparID<-c("-N","N", "+N")
Meancoef<-cbind(comparID, coef,confd,confdMin,confdMax);Meancoef

#2 Exponentially transformed and calculate changes in %
UnlogMean <- (exp(Meancoef[ ,2])*100)-100
UnlogConfdMax <- (exp(Meancoef[ ,7])*100)-100
UnlogConfdMin <- (exp(Meancoef[ ,6])*100)-100

unlogcombied <- cbind(Meancoef,UnlogMean,UnlogConfdMin,UnlogConfdMax)
Combine=rbind(unlogcombied)
length(Combine$comparID)
comparID_new=c(1:3)
Combine_new=cbind(comparID_new,Combine);Combine_new

#unlogcombied=unlogcombied[with(unlogcombied, order(-UnlogMean)),]
#write.csv (unlogcombied, file="unlogcombied")

# 3 plot the figure (start)
#install.packages("plotrix")
library(plotrix)
#win.graph(7,8)
#?plotCI
par(mfrow = c(1, 1),oma = c(2, 5, 2, 5))
#comparID=factor(comparID,levels=c(1,3,2))
#par()
plotCI(x=Combine_new$UnlogMean,
       y=c(1:3),
       ui=Combine_new$UnlogConfdMax,
       li=Combine_new$UnlogConfdMin, 
       yaxt="n", 
       err="x",
       pch=19, 
       xlim=c(-10,150),
       ylim=c(0,4),
       xlab=list("ЧӦֵ",font=2, cex=1.2), ylab ="",
       main=" ")

axis(2,at=c(1,2,3),
     las=1, 
     font=2, 
     oma = c(4, 8, 4, 4), 
     labels=c("TN��0.75","0.75<TN��1.4","TN>1.4"))
axis(4,at=c(1,2,3),
     las=1, 
     font=2, 
     oma = c(4, 8, 4, 4), 
     labels=c("(77)","(120)","(345)"))

abline(v=0,lty=1)



####meta�ع鷽�̣����Իع�

library(ggplot2)
library(dplyr)
library(ggpmisc)
library(cowplot)
library(gridExtra)

plot(data2$N,data2$lnR,
     xlab = "TN",ylab = "lnR")
y1<-lm(lnR~N,data = data2)
abline(y1)
summary(y1)


write.csv(data2,file = "F:/�о�������/R���Դ���/ģ��/ʦ�ַ���/��Ӧ��/TN/laketn.csv")


pLTP<-ggplot(data2,aes(P,lnR))+
  geom_point(color="grey50",size=3,alpha=0.6)+
  labs(title = "lnR~P",x="lake(TP)",y="lnR")+
  theme(plot.title = element_text(hjust = 0.5))
pLTP+stat_smooth(color="skyblue",fill="skyblue",method = "lm")

#���ӻع鹫ʽ
pLTN+
  stat_smooth(color="skyblue", formula = y~x,fill="skyblue",method = "lm")+
  stat_poly_eq(
    aes(label=paste(..eq.label..,..adj.rr.label..,sep = '~~~~')),
    formula = y~x, parse=TRUE,size=5,label.x=1,label.y=0.95)

#���ӷ�������
pLTN+ylim(0,2)+
  stat_smooth(color="skyblue",formula = y~x,fill="skyblue",method = "lm")+
  stat_poly_eq(
    aes(label=paste(..eq.label..,..adj.rr.label..,sep = '~~~~')),
    formula=y~x,parse=TRUE,size=3,label.x=1.0,label.y=1.0)+
  stat_fit_tb(tb.type = 'fit.anova',
              label.y.npc = "top",label.x.npc = "right")

#ϸ���Ż������
LTN<-pLTN +  ylim(0,2) + 
  stat_smooth(color = "skyblue", formula = y ~ x,fill = "skyblue", method = "lm") +
  theme(plot.title = element_text(hjust = 0.5))+
  stat_poly_eq(
    aes(label = paste(..eq.label.., ..adj.rr.label.., sep = '~~~~')),
    formula = y ~ x,  parse = TRUE,size = 4,label.x = 1.0, label.y = 1.0) +
  stat_fit_tb(method = "lm",
              method.args = list(formula = y ~ x),
              tb.type = "fit.anova",
              tb.vars = c(Effect = "term", 
                          "df",
                          "M.S." = "meansq", 
                          "italic(F)" = "statistic", 
                          "italic(P)" = "p.value"),
              label.y = 0.9, label.x = 1.0,
              size = 4,
              parse = TRUE
  )+
  theme_classic()


