library(plotrix)
#win.graph(7,8)
#?plotCI
par(mfrow = c(1, 1),oma = c(2, 5, 2, 5))
setwd("F:/�о�������/R���Դ���/ģ��/ʦ�ַ���/��Ӧ��/TN")
#comparID=factor(comparID,levels=c(1,3,2))
#par()
Combine_new1<-read.csv("Combine_newTP.csv")


plotCI(x=Combine_new1$UnlogMean,
       y=c(1:4),
       ui=Combine_new1$UnlogConfdMax,
       li=Combine_new1$UnlogConfdMin, 
       yaxt="n", 
       err="x",
       pch=19, 
       xlim=c(-50,650),
       ylim=c(0,5),
       xlab=list("ЧӦֵ",font=2, cex=1.2), ylab ="",
       main=" ")

axis(2,at=c(1,2,3,4),
     las=1, 
     font=2, 
     oma = c(4, 8, 4, 4), 
     labels=c("����","����","����","�ӿ�"))
axis(4,at=c(1,2,3,4),
     las=1, 
     font=2, 
     oma = c(4, 8, 4, 4), 
     labels=c("(1172)","(788)","(128)","(356)"))

abline(v=0,lty=1)

# 3 plot the figure (end)