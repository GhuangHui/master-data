#"Wed Feb 03 10:42:01 2021"
date()
library(Matrix)
library(lme4)
library(nlme)
library(lmerTest)
library(readxl)
library(tidyverse)
library(dplyr)
setwd("F:/�о�������/R���Դ���/ģ��/ʦ�ַ���/��Ӧ��")
data<-read.csv("lake.csv")

head(data)
length(data$study)
#  rows

#rename some long names in the dataset for easy coding :)
data$N=data$TN_mg_L
data$P=data$TP_mg_L
data$NP=data$TN_TP
data$Chl=data$Chl.a_ug_L

length(data$NP)
data$NP=as.numeric(data$NP)
max(data$NP)


# compute lnR for Chl 
uniq= unique(data$study)
uniq
length(uniq)
data1=c() 
data2=c()

# it is important to learn for loop in R
# try to understand one level for loop first, and second level and so on


for (i in 1:length(uniq)) 
{subdata=subset(data, study==uniq[i]) # for each study, make a subdata
#uniq_y=unique(subdata$Year)
#for (y in 1:length(uniq_y)) # for each year with a study, make a (sub)subdata
#{ subdata=subset(subdata, Year==uniq_y[y])
#uniq_C=unique(subdata$Crop)
#for (C in 1:length(uniq_C)) #for the crops of each study
#{subdata=subset(subdata,Crop==uniq_C)
#uniq_cou=unique(subdata$Cou)
#for (cou in 1:length(uniq_cou)) #for the countries of the each study, make a (sub) subdata
#{subdata_cou=subset(subdata, Cou==uniq_cou[cou])}
#uniq_cu=unique(subdata_cou$cu)
#for (cu in 1:length(uniq_cu)) # for the cultivar for each study, make a (sub)subdata
#{ subdata_cu=subset(subdata_cou, cu==uniq_cu[cu])}
med_NP1=mean(subdata$TN_TP_r)

subdata$NP_level[subdata$NP<med_NP1]="-NP"
subdata$NP_level[subdata$NP>=med_NP1]="+NP"
ref=min(subdata$Chl)
lnR=log(subdata$Chl/ref) # this is to calculate lnR for Chl
data1=cbind(subdata,lnR)
data2=rbind(data2,data1)}

data=data2
head(data)
tail(data)

unique(data$NP_level)
#unique(data$P_level)
table(data$NP_level)


min(data$lnR)
max(data$lnR)

# lnR ~ N level
model_d=lme(lnR~NP_level,random=~1|study,data)# mixed-effect model
summary(model_d)

#extract coefficients from the summary
summary(model_d)$tTable # try to understand the results
coef<-data.frame(summary(model_d)$tTable[c(1,2),c(1,2,5)]);coef 
# c(1,2) are row numbers, c(1,2,5) are column numbers
t_crit<-qt(0.025,summary(model_d)$tTable[c(1,2),3]);t_crit 
# to determine the value from t distribution 
confd<-coef[,2]*abs(t_crit)
confdMin <- coef[,1] - confd # lower limit
confdMax <- coef[,1] + confd # upper limit
comparID=c(1:2)
comparID<-c("-NP", "+NP")
Meancoef<-cbind(comparID, coef,confd,confdMin,confdMax);Meancoef

#2 Exponentially transformed and calculate changes in %
UnlogMean <- (exp(Meancoef[ ,2])*100)-100
UnlogConfdMax <- (exp(Meancoef[ ,7])*100)-100
UnlogConfdMin <- (exp(Meancoef[ ,6])*100)-100

unlogcombied <- cbind(Meancoef,UnlogMean,UnlogConfdMin,UnlogConfdMax)
Combine=rbind(unlogcombied)
length(Combine$comparID)
comparID_new=c(1:2)
Combine_new=cbind(comparID_new,Combine);Combine_new

#unlogcombied=unlogcombied[with(unlogcombied, order(-UnlogMean)),]
#write.csv (unlogcombied, file="unlogcombied")

# 3 plot the figure (start)
#install.packages("plotrix")
library(plotrix)
#win.graph(7,8)
#?plotCI
par(mfrow = c(1, 1),oma = c(2, 5, 2, 5))
#comparID=factor(comparID,levels=c(1,3,2))
#par()
plotCI(x=Combine_new$UnlogMean,
       y=c(1:2),
       ui=Combine_new$UnlogConfdMax,
       li=Combine_new$UnlogConfdMin, 
       yaxt="n", 
       err="x",
       pch=19, 
       xlim=c(-25,300),
       ylim=c(0,4),
       xlab=list("ЧӦֵ",font=2, cex=1.2), ylab ="",
       main=" ")

axis(2,at=c(1,2),
     las=1, 
     font=2, 
     oma = c(4, 8, 4, 4), 
     labels=c("(TN:TP)>16","(TN:TP)<16"))
axis(4,at=c(1,2),
     las=1, 
     font=2, 
     oma = c(4, 8, 4, 4), 
     labels=c("(361)","(138)"))

abline(v=0,lty=1)

# 3 plot the figure (end)